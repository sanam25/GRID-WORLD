﻿# MazePath

MazePath uses tabular Q-learning to navigate a 5 × 5 maze. The robot starts at (0, 0), crosses the wall barrier through the bottom row, and reaches the goal at (4, 4).

## Run the project

Install Python 3, open a terminal in this folder, and run:

```bash
python maze.py
```

The script uses the Python standard library. It trains the agent for 600 episodes, runs built-in verification checks, and prints JSON with training metrics, the learned route, and evaluation results.

## Evaluation

| Metric | Greedy Q-learning | Uniform random |
|---|---:|---:|
| Trials reaching the goal | 30/30 | 12/30 |
| Mean attempts | 8.00 | 67.67 |
| Mean return | 13.00 | -103.20 |
| Mean collisions | 0.00 | 21.97 |

Both policies use the same maze and an 80-attempt limit. The greedy route meets the eight-move lower bound.
