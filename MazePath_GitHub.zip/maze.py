﻿import random, json
from statistics import mean
N=5
START=(0,0)
GOAL=(4,4)
WALLS={(0,2),(1,2),(2,2),(3,2)}
MOVES=[(-1,0),(0,1),(1,0),(0,-1)]
def step(s,a):
    dr,dc=MOVES[a]
    t=(s[0]+dr,s[1]+dc)
    if t in WALLS or not all(0<=v<N for v in t):
        return s,-3,False
    return t,(20 if t==GOAL else -1),t==GOAL
def greedy(q,s):
    return max(range(4),key=lambda a:q[s][a])
def train(seed=7):
    rng=random.Random(seed)
    q={(r,c):[0.0]*4 for r in range(N) for c in range(N) if (r,c) not in WALLS}
    log=[]
    for ep in range(600):
        s=START
        total=0
        eps=max(.05,1-ep/500)
        for k in range(80):
            a=rng.randrange(4) if rng.random()<eps else greedy(q,s)
            t,r,done=step(s,a)
            q[s][a]+=.2*(r+(0 if done else .95*max(q[t]))-q[s][a])
            s=t
            total+=r
            if done: break
        log.append((k+1,total,done))
    return q,log
def trial(policy,seed):
    rng=random.Random(seed)
    s=START
    path=[s]
    total=hits=0
    for k in range(80):
        t,r,done=step(s,policy(s,rng))
        hits+=t==s
        s=t
        path.append(s)
        total+=r
        if done: break
    return k+1,total,done,hits,path
def checks(q):
    assert step(START,0)==(START,-3,False)
    assert step((0,1),1)==((0,1),-3,False)
    assert step(START,2)==((1,0),-1,False)
    assert step((4,3),1)==(GOAL,20,True)
    assert len(q)==21 and all(len(v)==4 for v in q.values())
    assert q[GOAL]==[0]*4
    assert q==train()[0]
    snap={s:v[:] for s,v in q.items()}
    assert trial(lambda s,r:greedy(q,s),0)[:4]==(8,13,True,0)
    assert trial(lambda s,r:0,0)[:4]==(80,-240,False,80)
    assert snap==q
def summary(rows):
    return [round(mean(col),2) for col in zip(*(r[:4] for r in rows))]
if __name__=='__main__':
    q,log=train()
    checks(q)
    stats={'blocks':[summary(log[i:i+100]) for i in range(0,600,100)],
           'learned':summary([trial(lambda s,r:greedy(q,s),i) for i in range(100,130)]),
           'random':summary([trial(lambda s,r:r.randrange(4),i) for i in range(100,130)]),
           'path':trial(lambda s,r:greedy(q,s),0)[4],
           'start_q':[round(v,3) for v in q[START]],
           'seeds':[trial(lambda s,r:greedy(train(i)[0],s),0)[:4] for i in []]}
    stats['seeds']=[]
    for i in [1,7,21]:
        model,_=train(i)
        stats['seeds'].append(trial(lambda s,r:greedy(model,s),0)[:4])
    print(json.dumps(stats))
